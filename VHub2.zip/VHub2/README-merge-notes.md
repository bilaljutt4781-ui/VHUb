
# Merged Project (VHub + Netlify)

**Buttons sirf show ke liye hain** — click par user Telegram bot par redirect hota hai.

## Configure
1. `public/config.js` open karein.
2. `TELEGRAM_BOT_USERNAME` me apne bot ka username (without @) likhein.

## How it works
- `index.html` par JazzCash/Easypaisa buttons hain.
- Click -> `redirectToTelegram(source)` -> `https://t.me/<BOT_USERNAME>?start=src=jazzcash&action=pay`
- Aap bot me `start` payload read karke user ko account number bhej sakte hain.

## Notes
- Agar project me already `index.html` tha to yeh file bhi root me create ki gayi hai (or kept your originals as `.from_zip2` if conflicts).
- Conflicting files from 2nd ZIP ko `.from_zip2` suffix ke saath rakha gaya hai.
