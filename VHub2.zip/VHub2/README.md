# VHub  (Netlify)

This is a minimal Netlify site demonstrating JazzCash and Easypaisa integrations.

## Quick Start
1. Deploy to Netlify (drag this folder or push to a repo).
2. In **Site settings → Environment variables**, add:
   - `JAZZCASH_MERCHANT_ID`
   - `JAZZCASH_PASSWORD`
   - `JAZZCASH_INTEGRITY_SALT`
   - `JAZZCASH_RETURN_URL` (e.g. `https://YOUR-SITE.netlify.app/return.html`)
   - `JAZZCASH_SANDBOX` = `true` for sandbox, `false` for live

   - `EASYPAY_MERCHANT_ID`
   - `EASYPAY_STORE_ID`
   - `EASYPAY_HASH_KEY`
   - `EASYPAY_RETURN_URL` (e.g. `https://YOUR-SITE.netlify.app/return.html`)
   - `EASYPAY_SANDBOX` = `true` for sandbox, `false` for live

3. Open the site and use the form to create a payment. You'll be redirected to the provider.
4. For webhooks, point the provider to `https://YOUR-SITE.netlify.app/webhook` (mapped to the serverless function).

> Important: Field names and endpoints sometimes vary by merchant setup/version. Confirm with your JazzCash/Easypaisa documentation or RM.
