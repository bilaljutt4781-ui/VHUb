window.TELEGRAM_BOT_USERNAME = "lisadavid_bot";  // required
window.TELEGRAM_CHAT_ID = "1542687237";          // optional